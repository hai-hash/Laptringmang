
import client.UDPClient1;
import java.io.IOException;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author longcon99
 */
public class MainClient {
    
    public static void main(String[] args) throws SocketException, IOException {
        UDPClient1 client1 = new UDPClient1();
        String studentCode = ";B17DCCN395";
        client1.send(studentCode);
        String mes = client1.reveive();
        String[] temp = mes.split("\\;");
        String[] a = temp[1].split("\\,");
        List<Integer> list= new ArrayList<>();
        for(String x : a){
            list.add(Integer.parseInt(x));
        }
        int max = list.get(0);
        int min = list.get(0);
        for(int i = 1; i < list.size(); i++){
            System.out.print(list.get(i) + " ");
            if(max < list.get(i)) max = list.get(i);
            if(min > list.get(i)) min = list.get(i);
        }
        System.out.println("");
        System.out.println(min + " " + max);
        String send = temp[0] + ";" + max + "," + min;
        client1.send(send);
        client1.close();
    }
}
