/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 *
 * @author longcon99
 */
public class UDPClient1 {
    
    DatagramPacket datagramPacket;
    DatagramSocket datagramSocket;
    int port;

    public UDPClient1() throws SocketException {
        datagramSocket = new DatagramSocket();
        port = 1107;
    }
    
    public void close(){
        if(datagramSocket!=null){
            datagramSocket.close();;
        }
    }
    
    public void send(String str) throws UnknownHostException, IOException{
        byte[] sendData = str.getBytes();
        datagramPacket = new DatagramPacket(sendData, sendData.length, InetAddress.getByName("localhost"), port);
        datagramSocket.send(datagramPacket);
    }
    
    public String reveive() throws IOException{
        byte[] receiveData = new byte[1024];
        datagramPacket = new DatagramPacket(receiveData, receiveData.length);
        datagramSocket.receive(datagramPacket);
        return new String(datagramPacket.getData()).trim();
    }
    
    
}
