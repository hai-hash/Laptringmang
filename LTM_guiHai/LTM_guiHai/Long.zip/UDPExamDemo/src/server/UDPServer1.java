/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author longcon99
 */
public class UDPServer1 {
    
    DatagramSocket datagramSocket;
    DatagramPacket datagramPacket;
    

    public UDPServer1() throws SocketException {
        datagramSocket = new DatagramSocket(1107);
        System.out.println("Server Ex1 Started ...");
    }
    
    public int findMax(List<Integer> list){
        int max = list.get(0);
        for(int i = 1; i < list.size(); i++){
            if(list.get(i) > max) max = list.get(i);
        }
        return max;
    }
    public int findMin(List<Integer> list){
        int min = list.get(0);
        for(int i = 1; i < list.size(); i++){
            if(list.get(i) < min) min = list.get(i);
        }
        return min;
    }
    
    public void listening() throws IOException{
        while(true){
            byte[] receiveData = new byte[1024];
            datagramPacket = new DatagramPacket(receiveData, receiveData.length);
            datagramSocket.receive(datagramPacket);
            String str=  new String(datagramPacket.getData()).trim();
            System.out.println(str);
            
            Random rand = new Random();
            int resquestId = rand.nextInt();
            String sendData = "request" + resquestId + ";";
            List<Integer> list = new ArrayList<>();
            for(int i = 0; i < 50 ; i++){
                int temp = rand.nextInt();
                sendData += temp + ",";
                list.add(temp);
            }
            sendData = sendData.substring(0, sendData.length() - 1);
            datagramPacket = new DatagramPacket(sendData.getBytes(), sendData.getBytes().length, datagramPacket.getAddress(), datagramPacket.getPort());
            datagramSocket.send(datagramPacket);
            int max = findMax(list);
            int min = findMin(list);
            receiveData = new byte[1024];
            datagramPacket = new DatagramPacket(receiveData, receiveData.length);
            datagramSocket.receive(datagramPacket);
            String res = new String(receiveData).trim();
            String comp = "request"+resquestId +";" + max + "," + min;
            if(res.equalsIgnoreCase(comp)) System.out.println("OK");
            else System.out.println("Fails");
        }
    }
    
    
    
    
}
